import React, { Component } from 'react';
import Header from 'components/Header';


class HeaderContainer extends Component {
    render() {
        return (
            <Header/>
        );
    }
}

export default HeaderContainer;