# react-memo-app

패스트캠퍼스 오프라인 강의에서 진행하는 프로젝트 중 하나인 json-server 로 만들어진 가짜 REST API 서버에 기반하여 리액트로 만들어진 메모앱 입니다.