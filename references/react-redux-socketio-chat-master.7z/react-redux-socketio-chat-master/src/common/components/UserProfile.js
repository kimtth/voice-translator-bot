import React from 'react';

export class UserProfile extends React.Component {
  render() {
    return (
      <div>
        User's Profile
      </div>
    );
  }
}
