var ids = {
  facebook: {
    clientID: '509360805905534',
    clientSecret: '6866390927213d6a21946f0fc852a881'
  }
}
module.exports = ids;
